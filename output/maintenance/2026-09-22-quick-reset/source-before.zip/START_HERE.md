# 여기서 시작하세요

**아래에서 지금 할 일 하나만 고르면 됩니다.** 모든 문서나 `AGENTS.md`를 읽을 필요는 없습니다.

| 지금 할 일 | 먼저 열 파일 | 이어서 볼 것 |
|---|---|---|
| **새 SD 설치부터 실물 테스트** | [새 SD 시작 안내](docs/guides/FRESH_SD_START.md) | 설치 후 [실기 확인표](docs/guides/PI_ACCEPTANCE_CHECKLIST.md) |
| **논문 작업** | [논문 작업 안내](docs/paper/README.md) | 수정할 [원고](docs/paper/PAPER_DRAFT_JDCS.md) · 읽을 [PDF](output/pdf/REFOUND_FULL_MANUSCRIPT.pdf) |
| **개선점 정리·발표 준비** | [개선점 한눈에 보기](docs/IMPROVEMENTS.md) | 필요한 항목의 상세 검토 기록만 읽기 |

현재 순서는 **새 SD에서 실물 테스트 → 문제 수정 → 안정되면 논문 또는 개선점 발표**입니다. 새 Pi 실기 검증과 논문용 정량 실험은 아직 수행하지 않았습니다.

기존 논문 발표 파일은 [PDF 캡처 방식의 4장 PPTX](output/presentation/REFOUND_PDF_CAPTURE_BRIEFING.pptx)입니다. **앱 개선점 발표용 PPTX는 아직 만들지 않았습니다.**

## 나머지 폴더는 언제 보나요?

| 위치 | 용도 |
|---|---|
| `dist/refound-pi.tar.gz` | 새 Pi에 복사할 최신 배포 파일. `.sha256`도 함께 사용 |
| `docs/guides/` | 설치·네트워크에 문제가 생겼을 때 찾는 상세 안내 |
| `docs/paper/` | 논문 원고·실험 설계·참고문헌 |
| `output/pdf/`, `output/presentation/` | 완성된 읽기·발표 파일. 현재 사용할 파일은 위 링크 기준 |
| `output/maintenance/` | 코드 변경 전 백업·검증 로그·화면. 평소에는 열 필요 없음 |
| `docs/Meeting_Minutes/`, `docs/Original_Ideas/`와 과거 보고서 | 팀 활동 보관 자료. 현재 설치 설명이 아님 |
| `data/` | 실제 DB·사진. 정리 대상으로 지우지 않음 |
| `AGENTS.md` | 다음 AI 세션이 읽는 지침. 사용자용 설명서는 이 문서 |

날짜가 붙은 이전 배포 파일, 이전 6장 PPTX, 논문 `archive/`는 과거 기록으로 보존합니다. 다음 AI에 작업을 이어 맡길 때는 **“AGENTS.md와 최신 인계 문서를 읽고, 설치 테스트 / 논문 / 개선점 발표 중 ○○부터 이어서 해줘”**라고 하면 됩니다.
