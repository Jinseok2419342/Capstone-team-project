# 다음 세션 인계 — 새 SD 재설치 후 실기 확인

## 현재 사용자 의도

이전 Raspberry Pi 실습은 성공했지만 microSD가 고장 났다. 사용자는 새 카드에 개선된 앱을 다시 설치하려 한다. 다음 세션에서는 실제로 테스트하고 잘 작동하면 **이전에 하던 논문 작업 또는 앱 개선점 발표 자료**로 넘어갈 예정이다. 어느 쪽인지는 아직 선택하지 않았다.

현재는 앱 추가 개편이나 논문 계측 개발을 자동으로 시작할 시점이 아니다. **새 카드의 설치·접속·실물 기능 확인이 우선**이다. 이 세션에서는 실제 카드 기록, Pi 접속·설치, 카메라·원격 AI·메일 실험을 하지 않았다.

## 사용자가 볼 문서와 파일

1. [새 SD 설치 안내](guides/FRESH_SD_START.md): OS → 설치 → 카메라/키 → SSH 터널 실물 확인 → 선택적 Tailscale
2. [실기 확인표](guides/PI_ACCEPTANCE_CHECKLIST.md): 미실시 상태의 양식. 실제 관찰로만 채운다.
3. 기본 배포 파일: `dist/refound-pi.tar.gz`, 무결성 파일: `dist/refound-pi.tar.gz.sha256`
4. 상세 참고서: [Pi 전체 가이드](guides/RASPBERRY_PI_GUIDE.md), [학교 운영](guides/SCHOOL_DEMO_GUIDE.md), [모니터·Wi-Fi 복구](guides/PI_MONITOR_WIFI_GUIDE.md)

날짜가 붙은 `dist/refound-pi-2026-09-18-live-flow.tar.gz`는 앞선 코드 검증 시점의 보관본이다. 새 설치는 **이번에 갱신한 기본 파일명**을 사용한다. 코드를 바꾸면 `package-for-pi.ps1 -Force`로 다시 생성한다. 배포에는 실제 `.env`·DB·사진을 넣지 않는다.

## 이번에 보완한 점

- 이전 학교 문서의 ‘현재 설치·Tailscale 완료’는 고장 전 카드의 과거 기록으로 정정했다. 이전 Tailscale 주소를 새 장치 주소로 오인하지 않도록 예시로 바꿨다.
- 새 카드의 SSH 호스트 키 경고는 해당 Pi임을 확인한 뒤 **그 주소의 기록만** 갱신한다. 새 Tailscale 인증·Serve 설정이 필요하며 중복 장치명에 접미사가 붙을 수 있다.
- 최초 접속은 `ssh -N -L 18000:127.0.0.1:8000 -o ExitOnForwardFailure=yes refound@refound-pi.local`을 열어 둔 뒤 PC의 `http://127.0.0.1:18000`에서 확인한다. Tailscale·비상 핫스팟은 앱 확인 뒤 선택한다.
- API 키는 유효하고 안전하게 보관 중이면 재사용할 수 있다. SD 고장만으로 폐기·재발급하지 않는다. 실제 키를 채팅·로그·발표 자료에 요청하거나 출력하지 않는다.
- `install.sh`는 서비스 사용자·가상환경으로 `check-runtime.py`를 실행해 NumPy/OpenCV/Picamera2와 웹 의존성을 실제 import한 뒤 서비스를 시작한다. apt 카메라 스택과 Pi 전용 requirements를 유지한다.
- `check-system.sh`는 OS·저장 공간·메모리·라이브러리·서비스·DB·카메라/개인정보 보호 상태를 읽기만 한다. 실제 카메라를 따로 열거나 AI/메일을 보내지 않는다. 설정된 주소·포트를 사용한다.
- `.env.example`의 무조건 `0.0.0.0` 공개 권유를 제거했다. 기본 loopback + SSH 터널/사설 Tailscale을 유지한다.

배포·진단 회귀 검사 **10개**와 이를 포함한 전체 Python **268개**가 통과했다. 최종 재검증 로그는 `output/maintenance/2026-09-18-fresh-sd/`를 따른다. 배포 검사는 Windows의 가짜 systemd/curl, 모의 import, 실제 임시 패키지를 사용하며 실제 Linux 설치·장치 호환 시험과 다르다. Python compileall과 새 문서의 로컬 링크도 확인했다. Node 33개 및 브라우저 16개 성공은 앞선 앱 개선 시점의 기록이며 이번에 재실행하지 않았다.

## 다음 세션 진행 순서

1. 사용자가 어디까지 설치했는지 먼저 파악한다. 이미 완료한 OS 쓰기·키 입력·Tailscale 인증을 반복시키지 않는다.
2. `check-system.sh` 결과와 확인표에서 실패·미실시인 항목을 중심으로 실제 실물을 추가·이동·제거한다. 키 설정 표시나 내장 예시 버튼은 AI 성공으로 세지 않는다.
3. 편집, 만료 알림, 연장, 폐기·복원, 개인정보 보호, 재접속·재부팅까지 확인한다. 물품·촬영 거리·조명·냉각·실제 OS와 모델을 기록한다.
4. 실패하면 그 경로를 재현·수정한다. 성공과 미실시를 섞어 ‘완전 성공’으로 기록하지 않는다.
5. 안정된 뒤 사용자 선택에 따라 아래 두 작업으로 이어간다.

**논문을 고르면:** 최신 코드를 기준으로 기존 초안의 구현 설명부터 대조한다. 특히 사건 반영 확인과 큐, 검토 상태, 지연 AI 처리, privacy 부팅 복원, 양쪽 provider의 JSON schema/완료 검사, 분석 영상과 미리보기 분리 설명이 달라졌다. 논문용 영속 계측·실험 원장은 별도 개발 단계이며 실기 리허설 결과를 정량 정확도·지연값으로 바꾸지 않는다. 기존 `[[...]]` placeholder 297종은 실제 측정 전까지 유지한다.

**개선점 발표를 고르면:** 문제 → 원인 → 변경 → 검증 → 현장 미확인/확인 결과 순서로 구성한다. 개선 전후 자료는 `APP_REVIEW_2026-09-18.md`, `VISION_REVIEW_2026-09-18.md`, `ARCHITECTURE_REVIEW_2026-09-18.md`, `LIVE_FLOW_REVIEW_2026-09-18.md`와 각 maintenance 폴더의 로그·화면을 사용한다. 합성 브라우저 화면과 실제 Pi 화면을 구분한다. 새 발표의 분량·대상은 아직 미정이다.

## 보존할 기존 논문·발표 상태

- `docs/paper/PAPER_DRAFT_JDCS.md`: 실측 전 전체 원고, 참고문헌 17개, placeholder 297종
- `output/pdf/REFOUND_FULL_MANUSCRIPT.pdf`: 19쪽
- `output/pdf/RESEARCH_FRONT_MATTER.pdf`: 발표 전반부 4쪽
- `output/presentation/REFOUND_PDF_CAPTURE_BRIEFING.pptx`: 최신 기존 발표 4장, PDF 페이지를 왼쪽에 그대로 넣고 오른쪽에 짧은 설명
- 사용자는 당시 본문 재조판과 대본을 원하지 않았다. 이번 새 ‘개선점 발표’에도 동일한 형식을 원하는지는 아직 확인하지 않았다.
- `docs/paper/manuscript/revise_manuscript.py`는 현재 편집을 덮어쓸 수 있으므로 실행하지 않는다. 원고에서 PDF만 다시 만들 때는 같은 폴더의 `build_manuscript.py`를 쓴다.

이번에는 원고·PDF·PPTX를 수정하지 않았다. 자세한 이전 문서 작업은 `docs/paper/SESSION_HANDOFF_2026-09-16.md`를 읽는다.

앞선 브라우저 검증의 `output/maintenance/2026-09-18-live-flow-review/browser-fixture-*` 임시 폴더는 삭제 자동 승인 거절로 남아 있다. 실제 운영 데이터가 아니며 실행·배포에 필요하지 않다. 이번 재설치 작업에서 삭제를 다시 시도하지 않았다.
