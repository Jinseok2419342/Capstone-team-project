# 프로젝트 문서

실행에 필요한 핵심 안내는 프로젝트 루트의 [README](../README.md)에 있습니다. 이 폴더에는 설치·시연 절차, 발표 자료, 캡스톤 산출물을 모아 둡니다.

## 설치 및 시연 가이드

- **시작점:** [새 microSD 재설치 안내](guides/FRESH_SD_START.md)
- [실기 확인표](guides/PI_ACCEPTANCE_CHECKLIST.md)
- [다음 세션 인계 — 실기 확인 후 논문·개선 발표](SESSION_HANDOFF_2026-09-18.md)
- [Raspberry Pi 전체 설치 가이드](guides/RASPBERRY_PI_GUIDE.md)
- [학교 시연 운영 가이드](guides/SCHOOL_DEMO_GUIDE.md)
- [모니터·키보드 현장 Wi-Fi 연결 가이드](guides/PI_MONITOR_WIFI_GUIDE.md)

## 코드 개선 및 검증

- [실제 운영 흐름 점검](LIVE_FLOW_REVIEW_2026-09-18.md)
- [사건 처리·운영 구조 개선](ARCHITECTURE_REVIEW_2026-09-18.md)
- [영상 안정성·성능 개선](VISION_REVIEW_2026-09-18.md)
- [앱 전체 검토](APP_REVIEW_2026-09-18.md)

## 발표 자료

- [발표 원고](presentation/PRESENTATION.md)
- [브라우저용 발표 화면](presentation/PRESENTATION.html)
- [초기 시스템 구성도](presentation/Blueprint.jpg)
- [발표 이미지 준비 목록](presentation/assets/README.md)
- [발표용 Mermaid 다이어그램](presentation/diagrams/README.md)

나머지 PDF·HWP 파일과 `Meeting_Minutes`, `Original_Ideas` 폴더는 팀 프로젝트의 기획·보고·회의 기록 원본입니다.
