"use strict";

// Run with: node --test tests/frontend/app.test.cjs
// Exercise the production controller with deferred HTTP responses and a tiny DOM.
const { test } = require("node:test");
const assert = require("node:assert/strict");
const { readFileSync } = require("node:fs");
const { join } = require("node:path");
const vm = require("node:vm");

class Element {
  constructor(options = {}) {
    this.dataset = {};
    this.attributes = new Map();
    this.children = [];
    this.innerHTML = "";
    this.textContent = "";
    this.value = "";
    this.disabled = false;
    this.hidden = false;
    this.open = false;
    this.isConnected = true;
    this.classes = new Set();
    this.classList = {
      add: (...names) => names.forEach((name) => this.classes.add(name)),
      remove: (...names) => names.forEach((name) => this.classes.delete(name)),
      contains: (name) => this.classes.has(name),
      toggle: (name, on) => on ? this.classes.add(name) : this.classes.delete(name),
    };
    Object.assign(this, options);
  }
  setAttribute(name, value) { this.attributes.set(name, String(value)); }
  getAttribute(name) { return this.attributes.get(name) ?? null; }
  hasAttribute(name) { return this.attributes.has(name); }
  removeAttribute(name) { this.attributes.delete(name); }
  toggleAttribute(name, on) { if (on) this.setAttribute(name, ""); else this.removeAttribute(name); }
  querySelector(selector) { return this.nodes?.[selector] || null; }
  querySelectorAll() { return []; }
  closest() { return null; }
  addEventListener() {}
  appendChild(child) { this.children.push(child); }
  focus() { this.focused = true; }
  showModal() { this.open = true; }
  close() { this.open = false; }
  set src(value) { this.setAttribute("src", value); }
  get src() { return this.getAttribute("src"); }
}

function setup() {
  const nodes = new Map();
  const groups = new Map();
  const requests = [];
  const document = {
    hidden: false,
    querySelector: (selector) => nodes.get(selector) || null,
    querySelectorAll: (selector) => groups.get(selector) || [],
    getElementById: (id) => nodes.get(`#${id}`) || null,
    createElement: () => new Element(),
    addEventListener() {},
  };
  const sandbox = {
    document, HTMLDialogElement: Element, HTMLImageElement: Element,
    URL, URLSearchParams, AbortController,
    navigator: { onLine: true },
    location: { origin: "http://localhost", hash: "" },
    history: { pushState() {} },
    window: { matchMedia: () => ({ matches: true }), setTimeout: () => 1, clearTimeout() {}, setInterval: () => 1, clearInterval() {}, scrollTo() {}, confirm: () => true, addEventListener() {} },
    FormData: class {
      constructor(form) { this.form = form; }
      get(name) { const input = this.form.elements.namedItem(name); return input && !input.disabled ? input.value : null; }
    },
    fetch(path, options) {
      return new Promise((resolve, reject) => {
        requests.push({ path, options, reject, reply: (data, status = 200) => resolve({ ok: status < 400, status, headers: { get: () => "application/json" }, json: async () => data }) });
      });
    },
  };
  const source = readFileSync(join(__dirname, "../../static/app.js"), "utf8");
  const exports = "state, loadDashboard, loadItems, openItem, loadSettings, settingsPayload, populateSettings, handleProviderChange, handleItemAction, saveItemEdit, syncCameraStreams, validateSettingsForm, effectiveStatus";
  vm.createContext(sandbox);
  vm.runInContext(source.replace(/\}\)\(\);\s*$/, `globalThis.app = { ${exports} }; })();`), sandbox);
  return { ...sandbox.app, document, nodes, groups, requests, add(selector, options) { const node = new Element(options); nodes.set(selector, node); return node; } };
}

const flush = () => new Promise((resolve) => setImmediate(resolve));
const item = (id, name = `물품 ${id}`) => ({ id, name, provider: "manual", category: "general", status: "stored", expires_at: "2099-01-01T12:34:56+00:00" });

test("recover, dispose and restore report success after the server commits", async () => {
  for (const action of ["recover", "dispose", "restore"]) {
    const app = setup();
    const toasts = app.add("#toast-region");
    const button = new Element({ dataset: { id: "1", itemAction: action } });
    const pending = app.handleItemAction(button);
    await flush();
    assert.equal(app.requests[0].path, `/api/items/1/${action}`);
    app.requests[0].reply(item(1));
    await flush();
    assert.equal(app.requests[1].path, "/api/dashboard");
    app.requests[1].reply({});
    await pending;
    assert.equal(toasts.children.length, 1);
    assert.equal(toasts.children[0].className, "toast success");
    assert.equal(button.disabled, false);
  }
});

test("a newer search survives an older response and an older error", async () => {
  for (const failOlder of [false, true]) {
    const app = setup();
    const search = app.add("#item-search", { value: "first" });
    const first = app.loadItems({ silent: true });
    search.value = "second";
    const second = app.loadItems({ silent: true });
    assert.equal(app.requests.length, 2);
    app.requests[1].reply({ items: [item(2)] });
    await second;
    if (failOlder) app.requests[0].reject(new Error("connection lost"));
    else app.requests[0].reply({ items: [item(1)] });
    await first;
    assert.equal(app.state.items[0].id, 2);
    assert.equal(app.state.itemsLoading, false);
  }
});

test("a refresh after mutation supersedes an in-flight identical query", async () => {
  const app = setup();
  const first = app.loadItems({ silent: true });
  const refresh = app.loadItems({ silent: true, force: true });
  app.requests[1].reply({ items: [item(3)] });
  await refresh;
  app.requests[0].reply({ items: [] });
  await first;
  assert.equal(app.state.items[0].id, 3);
});

test("older dashboard failure cannot take a newer successful connection offline", async () => {
  const app = setup();
  const first = app.loadDashboard();
  const refresh = app.loadDashboard({ force: true });
  app.requests[1].reply({ stats: { active: 3 } });
  await refresh;
  app.requests[0].reject(new Error("stale failure"));
  await first;
  assert.equal(app.state.dashboard.stats.active, 3);
  assert.equal(app.state.serverOnline, true);
});

test("opening a second item cannot be overwritten by the first item's response", async () => {
  const app = setup();
  app.add("#item-dialog");
  const title = app.add("#item-dialog-title");
  app.add("#item-dialog-content");
  const first = app.openItem(1);
  const second = app.openItem(2);
  app.requests[1].reply(item(2, "두 번째 물품"));
  await second;
  app.requests[0].reply(item(1, "첫 번째 물품"));
  await first;
  assert.equal(title.textContent, "두 번째 물품");
});

function settingsForm(app) {
  const values = {
    ai_provider: "auto", ai_model: "model-a", ai_min_confidence: "0.15", camera_index: "0",
    motion_delay_seconds: "20.25", motion_threshold: "3.75", privacy_mode: "",
    admin_email: "", smtp_host: "smtp.local", smtp_port: "587", smtp_username: "",
    valuable_value_threshold_krw: "100000",
  };
  const elements = Object.entries(values).map(([name, value]) => new Element({ name, value }));
  elements.namedItem = (name) => elements.find((element) => element.name === name) || null;
  app.add("#settings-form", { elements });
  app.nodes.set("#ai-provider", elements.namedItem("ai_provider"));
  app.nodes.set("#ai-model", elements.namedItem("ai_model"));
  return elements;
}

const settings = {
  provider: "auto", openai_model: "model-a", gemini_model: "model-b", ai_min_confidence: 0.15,
  camera_index: 0, settle_seconds: 20.25, motion_threshold: 3.75, privacy_mode: false,
  admin_email: "", smtp_host: "smtp.local", smtp_port: 587, smtp_username: "", valuable_value_threshold_krw: 100000,
};

test("opening settings during startup awaits the shared request and populates safe values", async () => {
  const app = setup();
  const fields = settingsForm(app);
  const button = app.add("#save-settings");
  const content = app.add("#settings-content");
  const startup = app.loadSettings({ populate: false, silent: true });
  const opened = app.loadSettings({ populate: true });
  assert.equal(app.requests.length, 1);
  assert.equal(button.disabled, true);
  assert.equal(content.inert, true);
  app.requests[0].reply({ settings, provider: { active: "openai" } });
  await Promise.all([startup, opened]);
  assert.equal(fields.namedItem("motion_threshold").value, "3.75");
  assert.equal(fields.namedItem("motion_delay_seconds").value, "20.25");
  assert.equal(fields.namedItem("ai_min_confidence").value, "0.15");
  assert.equal(button.disabled, false);
  assert.equal(content.inert, false);
  assert.equal(Object.keys(app.settingsPayload()).length, 0);
  fields.namedItem("admin_email").value = "test@example.invalid";
  assert.deepEqual(JSON.parse(JSON.stringify(app.settingsPayload())), { admin_email: "test@example.invalid" });
});

test("model edits survive switching providers and automatic selection", () => {
  const app = setup();
  const fields = settingsForm(app);
  app.state.settings = settings;
  app.state.provider = { active: "openai" };
  app.populateSettings(settings, app.state.provider);
  fields.namedItem("ai_model").value = "edited-a";
  fields.namedItem("ai_provider").value = "gemini";
  app.handleProviderChange();
  assert.equal(fields.namedItem("ai_model").value, "model-b");
  fields.namedItem("ai_model").value = "edited-b";
  fields.namedItem("ai_provider").value = "auto";
  app.handleProviderChange();
  assert.equal(fields.namedItem("ai_model").value, "edited-a");
  assert.deepEqual(JSON.parse(JSON.stringify(app.settingsPayload())), { openai_model: "edited-a", gemini_model: "edited-b" });
});

test("hidden streams disconnect; returning to the view opens only its stream", () => {
  const app = setup();
  const dashboard = { hidden: false };
  const camera = { hidden: true };
  const main = new Element({ dataset: { streamSrc: "/camera/stream" }, closest: () => dashboard });
  const secondary = new Element({ dataset: { streamSrc: "/camera/stream" }, closest: () => camera });
  secondary.setAttribute("data-camera-stream-secondary", "");
  app.groups.set('[data-camera-stream], [data-camera-stream-secondary]', [main, secondary]);
  app.syncCameraStreams();
  assert.ok(main.src);
  assert.equal(secondary.src, null);
  dashboard.hidden = true;
  camera.hidden = false;
  app.syncCameraStreams();
  assert.equal(main.src, null);
  assert.ok(secondary.src);
  app.document.hidden = true;
  app.syncCameraStreams();
  assert.equal(secondary.src, null);
  app.document.hidden = false;
  app.state.dashboard = { camera: { privacy_enabled: true } };
  app.syncCameraStreams();
  assert.equal(secondary.src, null);
  assert.equal(secondary.hidden, true);
});

test("saving only the name preserves the full-precision expiry timestamp", async () => {
  const app = setup();
  const fields = [
    new Element({ name: "name", value: "수정한 물품" }), new Element({ name: "description", value: "" }),
    new Element({ name: "category", value: "general" }), new Element({ name: "expires_at", value: "2099-01-01T12:34" }),
  ];
  fields.namedItem = (name) => fields.find((field) => field.name === name);
  const form = new Element({ elements: fields, dataset: { id: "1", originalCategory: "general", originalExpiry: "2099-01-01T12:34" } });
  const pending = app.saveItemEdit(form);
  const body = JSON.parse(app.requests[0].options.body);
  assert.equal(body.name, "수정한 물품");
  assert.equal("expires_at" in body, false);
  app.requests[0].reply(item(1));
  await flush();
  app.requests[1].reply({});
  await pending;
});

test("upcoming expiry follows the configured alert period, including zero days", () => {
  const app = setup();
  const stored = { status: "stored", expires_at: new Date(Date.now() + 3 * 86400000).toISOString() };
  assert.equal(app.effectiveStatus(stored), "due_soon");
  app.state.settings = { alert_lead_days: 1 };
  assert.equal(app.effectiveStatus(stored), "active");
  app.state.settings.alert_lead_days = 5;
  assert.equal(app.effectiveStatus(stored), "due_soon");
  app.state.settings.alert_lead_days = 0;
  assert.equal(app.effectiveStatus(stored), "active");
});
